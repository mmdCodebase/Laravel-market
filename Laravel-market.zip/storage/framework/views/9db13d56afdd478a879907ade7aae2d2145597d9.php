<?php $__env->startSection('title','Mnemonic reset'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-5 justify-content-center" >
        <div class="col-md-6 text-center">

            <h2>Reset password</h2>

            <div class="mt-3">
                <p>Please enter your username, mnemonic and your new password</p>

                <form method="POST" action="/forgotpassword/mnemonic">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group ">
                        <input type="text" class="form-control <?php if($errors->has('username')): ?> is-invalid <?php endif; ?>" placeholder="Username" name="username" id="username">
                        <?php if($errors->has('username')): ?>
                            <p class="text-danger"><?php echo e($errors->first('username')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group ">
                        <input type="text" class="form-control <?php if($errors->has('mnemonic')): ?> is-invalid <?php endif; ?>" placeholder="Mnemonic" name="mnemonic" id="mnemonic">
                        <?php if($errors->has('mnemonic')): ?>
                            <p class="text-danger"><?php echo e($errors->first('mnemonic')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-row">
                        <div class="col">
                            <input type="password" class="form-control <?php if($errors->has('password')): ?> is-invalid <?php endif; ?>" placeholder="New password" name="password"
                                   id="password">
                        </div>
                        <div class="col">
                            <input type="password" class="form-control <?php if($errors->has('password')): ?> is-invalid <?php endif; ?>" placeholder="Confirm new password"
                                   name="password_confirmation" id="password_confirm">
                        </div>

                    </div>

                    <?php if($errors->has('password')): ?>
                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                    <?php endif; ?>

                    <div class="form-group text-center">
                        <div class="row">
                            <div class="col-xs-12 col-md-4 offset-md-4">
                                <button type="submit" class="btn btn-outline-primary btn-block" style="margin-top: 15px;">Reset password</button>
                            </div>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/auth/forgotpassword/mnemonicpassword.blade.php ENDPATH**/ ?>