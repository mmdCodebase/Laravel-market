<?php if(session()->has('success')): ?>
    <div class="alert alert-success my-2 text-center">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?><?php /**PATH D:\Laravel-market\resources\views/includes/flash/success.blade.php ENDPATH**/ ?>