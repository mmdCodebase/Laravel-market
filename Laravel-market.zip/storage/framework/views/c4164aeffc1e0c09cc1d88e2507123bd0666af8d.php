<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="mb-3">
        <?php echo $__env->yieldContent('product-title'); ?>
    </h1>
    <hr>
    <?php if (\Illuminate\Support\Facades\Blade::check('vendor')): ?>
    <div class="accordion mb-3" id="accordionExample">
        <div class="card">
            <div class="card-header" id="headingOne">
                <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.edit', $basicProduct)); ?>">
                <?php else: ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.add', session('product_type'))); ?>">
                <?php endif; ?>
                    <h3>
                        <i class="fas fa-info-circle"></i>
                        Basic information
                    </h3>
                </a>
            </div>

            <?php echo $__env->yieldContent('product-basic-form'); ?>
        </div>
        <div class="card">
            <div class="card-header">
                <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'offers'])); ?>">
                <?php else: ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.offers')); ?>">
                <?php endif; ?>
                    <h3>
                        <i class="fas fa-money-check-alt"></i>
                        Price and offers
                    </h3>
                </a>
            </div>

            <?php echo $__env->yieldContent('product-offers-form'); ?>
        </div>
        <?php
            if(empty($type))
                $type = session('product_type');
        ?>
        <?php if($type == 'physical'): ?>
            <div class="card">
                <div class="card-header">
                    <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                        <a class="btn" href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'delivery'])); ?>">
                    <?php else: ?>
                        <a class="btn" href="<?php echo e(route('profile.vendor.product.delivery')); ?>">
                    <?php endif; ?>
                        <h3>
                            <i class="fas fa-truck"></i>
                            Delivery options
                        </h3>
                    </a>
                </div>

                <?php echo $__env->yieldContent('product-delivery-form'); ?>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'digital'])); ?>">
                <?php else: ?>
                    <a class="btn" href="<?php echo e(route('profile.vendor.product.digital')); ?>">
                <?php endif; ?>
                        <h3>
                            <i class="fas fa-desktop"></i>
                            Digital options
                        </h3>
                    </a>
                </div>

                <?php echo $__env->yieldContent('product-digital-form'); ?>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
            <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                <a class="btn" href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'images'])); ?>">
            <?php else: ?>
                <a class="btn" href="<?php echo e(route('profile.vendor.product.images')); ?>">
            <?php endif; ?>
                    <h3>
                        <i class="fas fa-images"></i>
                        Images
                    </h3>
                </a>
            </div>

            <?php echo $__env->yieldContent('product-images-form'); ?>
        </div>
    </div>

    <?php if(!request() -> is('profile/vendor/product/edit/*')): ?>
        <form method="POST" action="<?php echo e(route("profile.vendor.product.post")); ?>" class="text-center my-2">
            <?php echo e(csrf_field()); ?>

            <button class="btn btn-lg btn-block btn-success"><i class="far fa-plus-square mr-2"></i> Add product</button>
        </form>
    <?php endif; ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/master/productadding.blade.php ENDPATH**/ ?>