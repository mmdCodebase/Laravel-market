<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 class="my-3">Settings</h1>

    <h3 class="mt-4">Change password</h3>
    <hr>
    <form action="<?php echo e(route('profile.password.change')); ?>" method="POST" class="justify-content-between">
        <?php echo e(csrf_field()); ?>

        <div class="form-row my-2">
            <label for="old_password" class="col-form-label col-md-2">Old password:</label>
            <div class="col-md-10">
                <input type="password" class="form-control" id="old_password" name="old_password" placeholder="Type the old password">
            </div>
        </div>
        <div class="form-row my-2">
            <label for="new_password" class="col-form-label col-md-2">New password:</label>
            <div class="col-md-5">
                <input type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="new_password" name="new_password" placeholder="Type new password">
            </div>
            <div class="col-md-5">
                <input type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="new_password_confirmation" name="new_password_confirmation" placeholder="Confirm new password">
            </div>
        </div>
        <div class="form-row text-right justify-content-between">
            <div class="col-md-9 text-left">
                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback d-block"><?php echo e($errors -> first('new_password')); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3">
                <button class="btn btn-outline-success" type="submit">Change password</button>
            </div>
        </div>
    </form>
    <?php if(\App\Marketplace\Utility\CurrencyConverter::isEnabled()): ?>
        <?php echo $__env->make('multicurrency::changeform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <h3 class="mt-4">Two Factor Authentication</h3>
    <hr>
    <div class="row">
        <div class="col-md-6">
            <label>2-Factor Authentication:</label>
        </div>
        <div class="col-md-6 text-right">
            <div class="btn-group" role="group" aria-label="Basic example">
                <a href="<?php echo e(route('profile.2fa.change', true)); ?>" class="btn <?php if(auth() -> user() -> login_2fa == true): ?> btn-success <?php else: ?> btn-outline-success <?php endif; ?>">On</a>
                <a href="<?php echo e(route('profile.2fa.change', 0)); ?>" class="btn <?php if(auth() -> user() -> login_2fa == false): ?> btn-danger <?php else: ?> btn-outline-danger <?php endif; ?>">Off</a>
            </div>
        </div>
    </div>

    <h3 class="mt-4">Referral link</h3>
    <hr>
    <div class="row">
        <div class="col-md-12">
            <input type="url" readonly class="form-control disabled" value="<?php echo e(route('auth.signup', auth() -> user() -> referral_code)); ?>">
            <p class="text-muted">Paste this address to other users who wants to sign up on the market!</p>
        </div>
    </div>

    <h3 class="mt-4">Payment Addresses</h3>
    <hr>

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('profile.vendor.address')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-row">
                    <div class="col-md-6">
                        <input type="text" class="form-control form-control-lg d-flex" name="address" id="address" placeholder="Place your new address(pubkey) here">
                    </div>
                    <div class="col-md-2">
                        <select name="coin" id="coin" class="form-control form-control-lg d-flex">
                            <option>Coin</option>
                            <?php $__currentLoopData = config('coins.coin_list'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supportedCoin => $instance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supportedCoin); ?>"><?php echo e(strtoupper(\App\Address::label($supportedCoin))); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <button class="btn btn-block btn-success btn-lg">Change</button>
                    </div>
                </div>
            </form>
            <p class="text-muted">On this address you will receive payments from purchases! Funds will be sent to your most recent added address of coin!</p>


            <?php if(auth() -> user() -> addresses -> isNotEmpty()): ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Address</th>
                        <th>Coin</th>
                        <th class="text-right">Added</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = auth() -> user() -> addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="text" readonly class="form-control" value="<?php echo e($address -> address); ?>">
                            </td>
                            <td><span class="badge badge-info"><?php echo e(strtoupper($address -> coin)); ?></span></td>
                            <td class="text-muted text-right">
                                <?php echo e($address -> added_ago); ?>

                            </td>
                            <td class="text-right"><a href="<?php echo e(route('profile.vendor.address.remove', $address)); ?>" class="btn btn-danger"><i class="fa fa-trash mr-1"></i>Remove</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
            <?php else: ?>
                <div class="alert text-center alert-warning">You addresses list is empty!</div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/profile/index.blade.php ENDPATH**/ ?>