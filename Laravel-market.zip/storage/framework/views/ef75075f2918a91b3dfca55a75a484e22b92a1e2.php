<h4>Categories</h4>
<hr>
<div class="list-group categories">
    <?php echo $__env->make('includes.subcategories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\Laravel-market\resources\views/includes/categories.blade.php ENDPATH**/ ?>