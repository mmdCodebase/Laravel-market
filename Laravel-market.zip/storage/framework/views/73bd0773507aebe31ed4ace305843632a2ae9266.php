<?php $__env->startSection('admin-content'); ?>
    <div class="row mb-4">
        <div class="col">
            <h3>
                All disputes
            </h3>
        </div>
    </div>

    <table class="table">
        <thead>
        <tr>
            <th>Purchase</th>
            <th>Buyer</th>
            <th>Vendor</th>
            <th>Winner</th>
            <th>Total</th>
            <th>Time</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $allDisputes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('admin.purchase', $dispute -> purchase)); ?>" class="btn btn-sm btn-mblue mt-1"><?php echo e($dispute -> purchase -> short_id); ?></a>
                </td>
                <td>
                    <?php echo e($dispute -> purchase -> buyer -> username); ?>

                </td>
                <td>
                    <a href="<?php echo e(route('vendor.show', $dispute -> purchase -> vendor)); ?>"><?php echo e($dispute -> purchase -> vendor -> user -> username); ?></a>
                </td>
                <td>
                    <?php if($dispute -> isResolved()): ?>
                        <?php echo e($dispute -> winner -> username); ?>

                    <?php else: ?>
                        <span class="badge badge-warning">Unresolved</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($dispute->purchase->getSumLocalCurrency()); ?> <?php echo e($dispute -> purchase->getLocalSymbol()); ?>

                    
                </td>
                <td>
                    <?php echo e($dispute -> timeDiff()); ?>

                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($allDisputes->links('includes.paginate')); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/disputes.blade.php ENDPATH**/ ?>