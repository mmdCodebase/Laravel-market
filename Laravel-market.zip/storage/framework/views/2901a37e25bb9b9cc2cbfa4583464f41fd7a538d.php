<?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex invalid-feedback bg-danger text-white justify-content-center p-1 rounded">
            <?php echo e($error); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\Laravel-market\resources\views/includes/flash/invalid.blade.php ENDPATH**/ ?>