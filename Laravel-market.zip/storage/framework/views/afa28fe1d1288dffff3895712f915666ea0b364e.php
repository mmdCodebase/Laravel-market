<h3 class="mb-2">Open new Support Ticket</h3>

<form action="<?php echo e(route('profile.tickets.new')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="title">Ticket title</label>
        <input type="text" name="title" class="form-control" id="title" aria-describedby="title" placeholder="Enter ticket title">
    </div>
    <div class="form-group">
        <label for="text">Ticket message:</label>
        <textarea class="form-control" name="message" id="title" rows="5" placeholder="Enter ticket content"></textarea>
        <small class="form-text text-muted">Describe your problem with the market!</small>
    </div>

    <div class="form-group text-right">
        <button type="submit" class="btn btn-outline-primary">
            Open ticket
            <i class="far ml-2 fa-plus-square"></i>
        </button>
    </div>
</form>

<?php /**PATH D:\Laravel-market\resources\views/includes/profile/newticket.blade.php ENDPATH**/ ?>