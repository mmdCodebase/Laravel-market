<?php $__env->startSection('admin-content'); ?>

    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h3 class="mb-5">Categories</h3>

    <div class="row">
        <div class="col-md-6">
            <h4>List of categories (<?php echo e(count($categories)); ?>)</h4>
            <hr>
            <?php if($rootCategories -> isNotEmpty()): ?>
                <?php echo $__env->make('includes.admin.listcategories', ['categories' => $rootCategories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <div class="alert alert-warning text-center">There are no categories!</div>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <h4>Add new category</h4>
            <hr>
            <form action="<?php echo e(route('admin.categories.new')); ?>"  method="POST">
                <?php echo e(csrf_field()); ?>

                <input name="name" placeholder="Category name" class="form-control mb-3 <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?> is-invalid <?php endif; ?>"/>
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?>
                <div class="invalid-feedback d-block"><?php echo e($errors -> first('name')); ?></div>
                <?php endif; ?>
                <label for="parent_id">Parent category:</label>
                <select name="parent_id" class="form-control mb-3" id="parent_id">
                    <option value="" selected>No parent category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category -> id); ?>"><?php echo e($category -> name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-outline-success d-flex float-right" type="submit">Add category</button>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/categories.blade.php ENDPATH**/ ?>