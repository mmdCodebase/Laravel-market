<?php $__env->startSection('form-content'); ?>
    <form method="POST" action="<?php echo e(route('profile.vendor.product.add.post', optional($basicProduct) -> exists ? $basicProduct : null)); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="name">Product's name:</label>
                <input type="text" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?> is-invalid <?php endif; ?>" id="name"
                       name="name" placeholder="Product name" value="<?php echo e(optional($basicProduct) -> name); ?>"
                       maxlength="100">
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?>
                <div class="invalid-feedback d-block text-center">
                    <?php echo e($errors -> first('name')); ?>

                </div>
                <?php endif; ?>
            </div>

            <div class="form-group col-md-6">
                <label for="name">Product's category:</label>
                <select class="form-control " name="category_id">
                    <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category -> id); ?>"
                                <?php if($category -> id == optional($basicProduct) -> category_id): ?> selected <?php endif; ?>><?php echo e($category -> name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'category_id', $errors)): ?>
                <div class="invalid-feedback d-block text-center">
                    <?php echo e($errors -> first('category_id')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group">
            <label for="description">Product's description:</label>
            <textarea name="description" id="description"
                      class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'description', $errors)): ?> is-invalid <?php endif; ?>" rows="20"
                      placeholder="Details about the product"><?php echo e(optional($basicProduct) -> description); ?></textarea>
            <p>
                <i class="fab fa-markdown"></i> Styling with Markdown is supported
            </p>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'description', $errors)): ?>
            <div class="invalid-feedback d-block text-center">
                <?php echo e($errors -> first('description')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div style="display:none;" class="form-group">
            <label for="rules">Payment rules:</label>
            <textarea name="rules" id="rules" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'rules', $errors)): ?> is-invalid <?php endif; ?>"
                      rows="10"
                      placeholder="Rules of conducting business"> No rules
            </textarea>
            <p>
                <i class="fab fa-markdown"></i> Styling with Markdown is supported
            </p>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'rules', $errors)): ?>
            <div class="invalid-feedback d-block text-center">
                <?php echo e($errors -> first('rules')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="coins">Supported types:</label>
            <select name="types[]" id="types" multiple class="form-control">
                <?php $__currentLoopData = \App\Purchase::$types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $typeLongName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(auth()->user()->vendor->canUseType($type)): ?>
                        <option value="<?php echo e($type); ?>" <?php echo e(optional($basicProduct) -> supportsType($type) ? 'selected' : ''); ?>><?php echo e($typeLongName); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'types', $errors)): ?>
            <div class="invalid-feedback d-block text-center">
                <?php echo e($errors -> first('types')); ?>

            </div>
            <?php endif; ?>
        </div>


        <div class="form-group">
            <label for="coins">Supported coins:</label>
            <select name="coins[]" id="coins" multiple class="form-control">
                <?php $__currentLoopData = config('coins.coin_list'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin => $instance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($coin); ?>" <?php echo e(optional($basicProduct) -> supportsCoin($coin) ? 'selected' : ''); ?>><?php echo e(strtoupper(\App\Purchase::coinDisplayName($coin))); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'coins', $errors)): ?>
            <div class="invalid-feedback d-block text-center">
                <?php echo e($errors -> first('coins')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="quantity">Quantity</label>
                <input type="number" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'quantity', $errors)): ?> is-invalid <?php endif; ?>"
                       <?php if(optional($basicProduct) -> isAutodelivery()): ?> readonly <?php endif; ?>
                       name="quantity" id="quantity" min="1" placeholder="Number of products"
                       value="<?php echo e(optional($basicProduct) -> quantity); ?>">
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'quantity', $errors)): ?>
                <div class="invalid-feedback d-block text-center">
                    <?php echo e($errors -> first('quantity')); ?>

                </div>
                <?php endif; ?>
                <?php if(optional($basicProduct) -> isAutodelivery()): ?>
                    <p class="text-muted">The product is marked as autodelivery, you can't change quantity manually.</p>
                <?php endif; ?>
            </div>
            <div class="form-group col-md-6">
                <label for="mesure">Mesure</label>
                <input type="text" maxlength="10" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'mesure', $errors)): ?> is-invalid <?php endif; ?>"
                       id="mesure" name="mesure" placeholder="Unit of mesure(item, gram)"
                       value="<?php echo e(optional($basicProduct) -> mesure); ?>">
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'mesure', $errors)): ?>
                <div class="invalid-feedback d-block text-center">
                    <?php echo e($errors -> first('mesure')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-row justify-content-center">
            <div class="form-group col-md-3 text-center">
                <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                    <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                    <a href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'offers'])); ?>"
                       class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
                <?php elseif(request() -> is('admin/product/*')): ?>
                    <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                    <a href="<?php echo e(route('admin.product.edit', [$basicProduct, 'offers'])); ?>"
                       class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
                <?php else: ?>
                    <button class="btn btn-outline-primary" type="submit"><i class="fas fa-chevron-down mr-2"></i> Next
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.profile.addingform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/includes/profile/basicform.blade.php ENDPATH**/ ?>