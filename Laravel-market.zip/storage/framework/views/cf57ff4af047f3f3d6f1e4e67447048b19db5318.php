<?php $__env->startSection('title','Forgot Password'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 justify-content-center" >
        <div class="col-md-4 text-center">
            <h2>Forgot your password?</h2>
            <div class="alert alert-warning">
                Note that you will not be able to read messages encrypted by the key from previous password.
            </div>
            <div class="mt-3">
                <p>Please choose how to recover it</p>

                <form method="GET" action="/forgotpassword/pgp">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-center">
                        <div class="row">
                            <button type="submit" class="btn btn-outline-primary btn-block">PGP</button>
                        </div>
                    </div>
                </form>

                <form method="GET" action="/forgotpassword/mnemonic">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-center">
                        <div class="row">
                            <button type="submit" class="btn btn-outline-primary btn-block">Mnemonic</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/auth/forgotpassword/forgotpassword.blade.php ENDPATH**/ ?>