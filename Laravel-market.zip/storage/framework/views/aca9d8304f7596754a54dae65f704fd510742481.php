<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                List of Users
            </h4>
            <hr>
        </div>
    </div>


    <div class="row mt-2">

        <div class="col">
            <form action="<?php echo e(route('admin.users.query')); ?>" method="post" class="">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Username:</label><br>
                            <input type="text" name="username" class="form-control" placeholder="Username of the user">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Order by:</label><br>
                            <select name="order_by" id="" class="form-control" title="Order by">
                                <option value="newest"
                                        <?php if(app('request')->input('order_by') =='newest'): ?> selected <?php endif; ?>>Newest
                                </option>
                                <option value="oldest"
                                        <?php if(app('request')->input('order_by') =='oldest'): ?> selected <?php endif; ?>>Oldest
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Display only: </label><br>
                            <select name="display_group" id="" class="form-control" title="Display group">
                                <option value="everyone"
                                        <?php if(request('display_group') =='everyone'): ?> selected <?php endif; ?>>
                                    Everyone
                                </option>
                                <option value="administrators"
                                        <?php if(request('display_group') =='administrators'): ?> selected <?php endif; ?>>
                                    Administrators
                                </option>
                                <option value="vendors"
                                        <?php if(request('display_group') =='vendors'): ?> selected <?php endif; ?>>Vendors
                                </option>
                                <option value="moderators"
                                        <?php if(request('display_group') =='moderators'): ?> selected <?php endif; ?>>Moderators
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group" style="margin-top:2em">
                            <button type="submit" class="btn btn-primary">Apply filter</button>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col">

        </div>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th>Username</th>
            <th>Group</th>
            <th>Last Login</th>
            <th>Registration Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($user->username); ?>

                </td>
                <td>
                    <?php if($user->getUserGroup()['badge']): ?>
                        <span class="badge badge-<?php echo e($user->getUserGroup()['color']); ?>"><?php echo e($user->getUserGroup()['name']); ?></span>
                    <?php else: ?>
                        <?php echo e($user->getUserGroup()['name']); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($user->lastSeenForHumans()); ?>

                </td>
                <td>
                    <?php echo e($user->created_at); ?>

                </td>
                <td>
                    <a href="<?php echo e(route('admin.users.view',['user'=>$user->id])); ?>" class="btn btn-secondary"> <i class="fas fa-search-plus"></i> View</a>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/users.blade.php ENDPATH**/ ?>