<?php $__env->startSection('admin-content'); ?>

    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="mb-5">Categories</h1>

    <div class="row">
        <div class="col-md-6">
            <h3>Edit category - <em><?php echo e($category -> name); ?></em></h3>
            <hr>
            <form action="<?php echo e(route('admin.categories.edit', $category -> id)); ?>"  method="POST">
                <?php echo e(csrf_field()); ?>

                <label for="name">Category name</label>
                <input name="name" id="name" placeholder="Category name" value="<?php echo e($category -> name); ?>" class="form-control mb-3 <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?> is-invalid <?php endif; ?>"/>
                <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?>
                <div class="invalid-feedback d-block"><?php echo e($errors -> first('name')); ?></div>
                <?php endif; ?>
                <label for="parent_id">Parent category:</label>
                <select name="parent_id" class="form-control mb-3" id="parent_id">
                    <option value="" <?php if($category -> parent_id == null): ?> selected <?php endif; ?>>No parent category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat -> id); ?>" <?php if($category -> parent_id == $cat -> id): ?> selected <?php endif; ?>><?php echo e($cat -> name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-outline-success d-flex float-right" type="submit">Add category</button>
            </form>
        </div>
        <div class="col-md-6">
            <?php if($category -> parent): ?>
                <h3>Parent Category</h3>
                <hr>
                <a href="<?php echo e(route('admin.categories.show', $category -> parent -> id)); ?>"><strong><?php echo e($category -> parent -> name); ?></strong></a>
            <?php endif; ?>
            <?php if($category -> children -> isNotEmpty()): ?>
                <h3 class="mt-3">Subcategories of this category</h3>
                <hr>
                <?php echo $__env->make('includes.admin.listcategories', ['categories' => $category -> children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/category.blade.php ENDPATH**/ ?>