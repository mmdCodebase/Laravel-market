<?php $__env->startSection('admin-content'); ?>
    <div class="row mb-4">
        <div class="col">
            <h3>
                All Tickets
            </h3>
        </div>
    </div>

    <div class="row mt-1 mb-3">
        <div class="col">
            <form action="<?php echo e(route('admin.tickets.remove')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-outline-info" name="type" value="solved">Remove solved tickets</button>
                <button type="submit" class="btn btn-outline-info" name="type" value="all">Remove all tickets</button>

                <div class="input-group mb-3 mt-2">
                    <input type="text" class="form-control" placeholder="Older than (Days)" name="days" aria-label="Days" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-outline-info" type="submit" name="type" value="orlder_than_days">Remove all</button>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <table class="table">
        <thead>
        <tr>
            <th>Title</th>
            <th>Opened by</th>
            <th>Time</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('admin.tickets.view', $ticket)); ?>" class="mt-1"><?php echo e($ticket -> title); ?></a>
                    <?php if($ticket -> solved): ?>
                    <span class="badge badge-success">Solved</span>
                    <?php else: ?>
                        <?php if($ticket -> answered): ?>
                            <span class="badge badge-warning">Answered</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <strong><?php echo e($ticket -> user -> username); ?></strong>
                </td>
                <td>
                    <small><?php echo e($ticket -> time_passed); ?></small>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($tickets->links('includes.paginate')); ?>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/tickets.blade.php ENDPATH**/ ?>