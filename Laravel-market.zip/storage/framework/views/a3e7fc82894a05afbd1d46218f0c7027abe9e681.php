<?php $__env->startSection('form-content'); ?>
<h3>Add image</h3>
<hr>
<form action="<?php echo e(route('profile.vendor.product.images.post', $basicProduct)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <input type="file" class="form-control border-0" name="picture" id="picture">
    </div>
    <div class="form-inline">
        <div class="form-check mx-2 mb-2 ">
            <input class="form-check-input" type="checkbox" value="1" name="first" id="defaultcheck">
            <label class="form-check-label" for="defaultcheck">
                Default product image
            </label>
        </div>

        <button type="submit" class="btn btn-primary mb-2">Add image</button>
    </div>
</form>



<h3 class="mt-3">Images of the product</h3>
<hr>
<p class="text-muted">Default picture is marked with green borders.</p>
<?php if(!empty($productsImages ?? [])): ?>
<div class="card-columns">
    <?php $__currentLoopData = $productsImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card my-3 p-2 <?php if($image -> first): ?> bg-success <?php endif; ?>">
            <img class="card-img" src="<?php echo e(asset('storage/' . $image -> image)); ?>" alt="Product image">
            <div class="card-img-overlay text-center">
                <?php if(!$image -> first): ?>
                    <a href="<?php echo e(route('profile.vendor.product.images.default', $image -> id)); ?>" class="btn btn-sm btn-primary">Default</a>
                    <a href="<?php echo e(route('profile.vendor.product.images.remove', $image -> id)); ?>" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i></a>
                <?php else: ?>
                    <p class="bg-white text-muted">Default picture</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    <div class="col-12 text-center alert alert-warning">
        You don't have any images added, it must be at least one!
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.profile.addingform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/includes/profile/imagesform.blade.php ENDPATH**/ ?>