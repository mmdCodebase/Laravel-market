<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                Bitmessage
            </h4>
            <hr>
            <table class="table table-bordered table-hover">
                <thead>
                    <th>Name</th>
                    <th>Status</th>
                </thead>
                <tr>
                    <td>
                        Bitmessage service
                    </td>
                    <td>
                        <?php if($enabled): ?>
                            <span class="badge badge-success">Enabled</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Disabled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Service test
                    </td>
                    <td>
                        <?php if($test): ?>
                            <span class="badge badge-success">Online</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Offline</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Marketplace address
                    </td>
                    <td>
                        <?php if($address !== null && $address !== ''): ?>
                            <span><?php echo e($address); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger">Not set</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/bitmessage.blade.php ENDPATH**/ ?>