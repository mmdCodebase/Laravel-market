<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                Displaying details for user <?php echo e($user->username); ?>

            </h4>
            <hr>
        </div>
    </div>

    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card mt-3">
        <form action="<?php echo e(route('admin.user.edit.info',$user->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="card-header">
                Basic information
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">

                        <div class="form-group">
                            <label for="id">ID:</label>
                            <input type="text" name="id" id="id" class="form-control" value="<?php echo e($user->id); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" name="username" id="username" class="form-control"
                                   value="<?php echo e($user->username); ?>" >
                        </div>


                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="referral_code">Referral code:</label>
                            <input type="text" name="referral_code" id="referral_code" class="form-control"
                                   value="<?php echo e($user->referral_code); ?>" >
                        </div>

                        <div class="form-group">
                            <label for="last_login">Last login:</label>
                            <input type="text" name="last_login" id="last_login" class="form-control"
                                   value="<?php echo e($user->lastSeenForHumans()); ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-outline-secondary">
                    Save Changes
                </button>
            </div>
        </form>
    </div>


    <div class="card mt-3">
        <form action="<?php echo e(route('admin.user.edit.group',$user->id)); ?>" method="post">

            <?php echo e(csrf_field()); ?>

            <div class="card-header">
                User Groups
            </div>

            <div class="card-body">

                <div class="row">

                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" name="administrator" type="checkbox" value="adminChecked"
                                   id="administratorCheck"
                                   <?php if($user->isAdmin()): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="administratorCheck">
                                Administrator
                            </label>
                        </div>
                        <small class="form-text text-muted">Can access Admin Panel without the restrictions. Can change
                            User group
                        </small>
                    </div>
                    <div class="col-md-4">
                        Panel Permissions

                        <?php $__currentLoopData = \App\User::$permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <label class="form-check-label">
                                <input class="form-check-input" <?php if($user -> hasPermission($permission)): ?> checked <?php endif; ?> name="permissions[]" type="checkbox" value="<?php echo e($permission); ?>"
                                       id="moderatorCheck">
                                <?php echo e(\App\User::$permissionsLong[$permission]); ?>

                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <small class="form-text text-muted">Limited access to Admin Panel. Mainly resolves disputes
                        </small>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" name="vendor" type="checkbox" value="vendorChecked"
                                   id="vendorCheck"
                                   <?php if($user->isVendor()): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="vendorCheck">
                                Vendor
                            </label>
                        </div>
                        <small class="form-text text-muted">Give or take away user's ability to add new products</small>

                        <div class="form-check">
                            <input class="form-check-input" name="canUseFe" type="checkbox" value="feChecked"
                                   id="vendorCheck"
                                   <?php if(!$user->isVendor() || !\App\Marketplace\Payment\FinalizeEarlyPayment::isEnabled()): ?> disabled <?php else: ?>  <?php if($user->vendor->canUseFe()): ?>checked  <?php endif; ?> <?php endif; ?>>
                            <label class="form-check-label" for="canUseFe">
                                Finalize Early Access <?php if(!\App\Marketplace\Payment\FinalizeEarlyPayment::isEnabled()): ?> feature not present <?php endif; ?>
                            </label>
                        </div>

                    </div>


                </div>

            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-outline-secondary">
                    Save Changes
                </button>
            </div>
        </form>
    </div>



    <div class="card mt-3">
        <div class="card-header">
            Vendor stats
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 text-center">
                    <p><?php echo e($user->products()->count()); ?></p>
                    <h6>Total Products</h6>
                </div>
                <div class="col-md-4 text-center">
                    <p><?php echo e($user->purchases()->count()); ?></p>
                    <h6>Total Sales</h6>
                </div>
            </div>
        </div>

        <div class="card-footer">
            <a href="<?php echo e(route('admin.products',['user'=>$user->id])); ?>" class="btn btn-outline-secondary">View user's products</a>
        </div>
    </div>

    <div class="card mt-3" id="bans">
        <div class="card-header">
            Bans
        </div>
        <div class="card-body">
            <?php if($user->bans->isEmpty()): ?>
                <div class="alert alert-info">List of bans is empty.</div>
            <?php else: ?>
                <?php $__currentLoopData = $user->bans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row my-1">
                        <div class="col-md-9 text-left text-muted">
                            Banned until <strong><?php echo e($ban -> until); ?></strong> (<?php echo e(\Carbon\Carbon::parse($ban->until)->diffForHumans()); ?>)
                        </div>
                        <div class="col-md-3 text-right">
                            <a href="<?php echo e(route('admin.ban.remove', $ban)); ?>" class="btn btn-outline-danger">Remove ban</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="card-footer">
            <form class="form-inline" method="POST" action="<?php echo e(route('admin.user.ban', $user)); ?>">
                <label for="days">Ban user for number of days from now:</label>
                <input type="number" name="days" id="days" class="form-control mx-2" placeholder="Days">
                <input type="submit" class="btn btn-outline-danger" value="Ban">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>


    <?php if($user -> isVendor()): ?>
        <div class="card mt-3" id="bans">
            <div class="card-header">
                Vendor purchase
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Coin</th>
                        <th>Address</th>
                        <th>Paid</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $user -> vendorPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depositAddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="badge badge-info"><?php echo e(strtoupper($depositAddress -> coin)); ?></span>
                            </td>
                            <td>
                                <input type="text" readonly class="form-control" value="<?php echo e($depositAddress -> address); ?>"/>
                            </td>
                            <td class="text-right">
                                <span class="badge badge-primary"><?php echo e($depositAddress -> amount); ?></span>
                            </td>
                            <td class="text-right">
                                <?php if($depositAddress -> isEnough()): ?>
                                    <span class="badge badge-success">Enough funds</span>
                                <?php endif; ?>
                                <span class="badge badge-info"><?php echo e($depositAddress -> balance); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/admin/user.blade.php ENDPATH**/ ?>