<?php $__env->startSection('title', 'Vendor Settings'); ?>

<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 class="mb-3">Vendor settings</h1>
    <hr>
    <?php if (\Illuminate\Support\Facades\Blade::check('vendor')): ?>
        

        <?php echo $__env->make('includes.profile.vendor.experience', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('includes.profile.vendor.editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('includes.profile.vendor.addproduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('includes.profile.vendor.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        
        <h3>Become vendor</h3>
        <hr>
        <div class="alert alert-warning text-center my-2">You don't have vendor status yet. Become vendor sell products
            on this store.
        </div>
        <div class="text-center">
            <a href="<?php echo e(route('profile.vendor.become')); ?>" class="btn btn-outline-success btn-md">Become vendor</a>
        </div>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/profile/vendor.blade.php ENDPATH**/ ?>