<?php $__env->startSection('product-content'); ?>


    <p><?php echo \GrahamCampbell\Markdown\Facades\Markdown::convertToHtml(nl2br(e($product -> description))); ?></p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/product/index.blade.php ENDPATH**/ ?>