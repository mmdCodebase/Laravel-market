<?php $__env->startSection('profile-content'); ?>

    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 class="mb-3">Your old PGP keys:</h1>
    <hr>
    <?php if($keys -> isNotEmpty()): ?>
        <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <textarea class="form-control disabled" rows="10" style="resize: none;" disabled readonly><?php echo e($pgp -> key); ?></textarea>
                <p class="text-muted">Used until <?php echo e($pgp -> timeUntil() -> diffForHumans()); ?>.</p>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert-warning">You don't have previous PGP keys.</div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/profile/oldpgp.blade.php ENDPATH**/ ?>