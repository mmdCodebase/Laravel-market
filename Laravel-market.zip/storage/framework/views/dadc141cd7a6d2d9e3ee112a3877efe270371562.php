<div class="collapse show">
    <div class="card-body">
        <?php echo $__env->yieldContent('form-content'); ?>
    </div>
</div><?php /**PATH D:\Laravel-market\resources\views/includes/profile/addingform.blade.php ENDPATH**/ ?>