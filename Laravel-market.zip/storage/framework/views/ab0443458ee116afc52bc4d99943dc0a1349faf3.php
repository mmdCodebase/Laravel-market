<?php $__env->startSection('title', 'Profile settings'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3">
            <?php echo $__env->make("includes.profile.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
<div class="col-md-9">
    <?php echo $__env->yieldContent("profile-content"); ?>
</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/master/profile.blade.php ENDPATH**/ ?>