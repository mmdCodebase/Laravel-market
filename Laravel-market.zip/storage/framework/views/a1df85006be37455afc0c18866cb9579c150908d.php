<?php echo e(\App\Marketplace\Utility\CurrencyConverter::convertToLocal($usdValue)); ?>

<?php echo e(\App\Marketplace\Utility\CurrencyConverter::getSymbol(\App\Marketplace\Utility\CurrencyConverter::getLocalCurrency())); ?><?php /**PATH D:\Laravel-market\resources\views/includes/currency.blade.php ENDPATH**/ ?>