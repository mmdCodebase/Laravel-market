<div class="form-group  mt-3">
    <div class="text-center">
        <img src="<?php echo e($captcha); ?>" alt="">
    </div>
    <input class="form-control mt-3 <?php if($errors->has('captcha')): ?> is-invalid <?php endif; ?>" type="text" name="captcha" placeholder="Enter Captcha">
    <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger"><?php echo e($errors->first('captcha')); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div><?php /**PATH D:\Laravel-market\resources\views/includes/captcha.blade.php ENDPATH**/ ?>