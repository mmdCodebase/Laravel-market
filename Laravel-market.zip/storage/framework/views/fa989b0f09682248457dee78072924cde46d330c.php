<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1 class="mb-3">Notifications</h1>
    <hr>
    <p>List of your notifications. You can delete them any time</p>
    <form action="<?php echo e(route('profile.notifications.delete')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <button type="submit" class="btn btn-outline-danger"><i class="fa fa-trash"></i> Delete notifications
            </button>
        </div>
    </form>
    <table class="table table-hover">
        <thead>
        <th>Notification</th>
        <th>Time</th>
        <th>Action</th>
        </thead>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($notification->description); ?>

                </td>
                <td>
                    <?php echo e($notification->created_at->diffForHumans()); ?>

                </td>
                <td>
                    <?php if($notification->getRoute() !== null ): ?>
                        <a href="<?php echo e(route($notification->getRoute(),$notification->getRouteParams())); ?>" class="btn btn-outline-secondary"><i class="fa fa-eye"></i> View</a>
                    <?php else: ?>
                        None
                    <?php endif; ?>
                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="mt-3">
        <?php echo e($notifications->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/profile/notifications.blade.php ENDPATH**/ ?>