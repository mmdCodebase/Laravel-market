<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-3">PGP keys</h1>
        </div>
        <div class="col-md-6">
            <h3 class="mb-3">Your pgp key</h3>
            <hr>

            <?php if(auth() -> user() -> hasPGP()): ?>
                <p>Your PGP key is:</p>
                <textarea class="disabled form-control" style="resize: none" rows="10" disabled><?php echo e(auth() -> user() -> pgp_key); ?></textarea>
            <?php else: ?>
                <div class="alert alert-warning text-center my-3">
                    You don't have PGP key set! Please set the PGP key in the form below.
                </div>
            <?php endif; ?>
            <p><a href="<?php echo e(route('profile.pgp.old')); ?>">Old PGP keys</a></p>

        </div>
        <div class="col-md-6">
            <h3 class="mb-3">Set new PGP key</h3>
            <hr>

            <form method="POST" action="<?php echo e(route('profile.pgp.post')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="newpgp">New PGP key:</label>
                    <textarea name="newpgp" id="newpgp" style="resize: none" rows="10" class="form-control <?php $__errorArgs = ['newpgp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                    <?php $__errorArgs = ['newpgp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors -> first('newpgp')); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p class="text-muted">Paste your public PGP key here and later you'll need to confirm.</p>
                </div>
                <div class="form-group text-center">
                    <button class="btn btn-outline-success" type="submit">Add PGP</button>
                </div>

            </form>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel-market\resources\views/profile/pgp.blade.php ENDPATH**/ ?>