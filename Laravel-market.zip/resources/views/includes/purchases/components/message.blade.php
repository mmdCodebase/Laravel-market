<div class="col-md-6">
    <h3 class="my-2" id="message">Message for vendor</h3>
    <hr>
    <p class="text-muted">Encrypted with vendor's PGP key.</p>
    <textarea rows="10" readonly class="form-control">{{ $purchase -> message }}</textarea>
</div>