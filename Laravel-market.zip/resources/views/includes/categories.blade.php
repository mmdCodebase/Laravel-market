<h4>Categories</h4>
<hr>
<div class="list-group categories">
    @include('includes.subcategories', ['categories' => $categories])
</div>