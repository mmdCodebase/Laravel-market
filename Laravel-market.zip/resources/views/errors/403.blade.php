@extends('master.main')

@section('title','Error hapend')

@section('content')


    <div class="text-center">
        <h1 class="text-danger my-3">404 Page not found</h1>
        <p class="display-4">This is not the page you are looking for!</p>
    </div>


@stop