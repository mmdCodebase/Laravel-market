<?php


namespace App\Marketplace\Utility\MoneroRPC\Exceptions;


class RuntimeException extends \Exception
{

}